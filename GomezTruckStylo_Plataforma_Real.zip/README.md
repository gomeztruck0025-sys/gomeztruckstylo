# GomezTruckS'tylo — plataforma real

## Qué incluye
- Registro e inicio de sesión.
- Base de datos SQLite.
- Publicación de camiones.
- Subida de fotografías.
- Galería pública.
- Me gusta.
- Diseño adaptable a celular.

## Ejecutar
1. Instala Node.js 20 o superior.
2. Abre una terminal en esta carpeta.
3. Ejecuta `npm install`.
4. Ejecuta `npm start`.
5. Abre `http://localhost:3000`.

## Para ponerla en Internet
Sube este proyecto a un servidor que soporte Node.js. Para producción conviene cambiar SQLite por PostgreSQL y usar almacenamiento de imágenes tipo S3/Supabase Storage. También conviene añadir moderación, recuperación de contraseña y sesiones seguras.
