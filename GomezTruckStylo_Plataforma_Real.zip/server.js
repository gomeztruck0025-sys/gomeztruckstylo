const express=require("express");
const path=require("path");
const fs=require("fs");
const multer=require("multer");
const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const {randomUUID}=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const db=new Database("gomeztruckstylo.db");
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS trucks(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,name TEXT NOT NULL,description TEXT,image TEXT,likes INTEGER DEFAULT 0,created_at TEXT NOT NULL);
`);

const uploadDir=path.join(__dirname,"uploads");
fs.mkdirSync(uploadDir,{recursive:true});
const storage=multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>{
 const ext=path.extname(file.originalname).toLowerCase();
 cb(null,Date.now()+"-"+randomUUID()+ext);
}});
const upload=multer({storage,limits:{fileSize:8*1024*1024},fileFilter:(req,file,cb)=>{
 if(/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) cb(null,true); else cb(new Error("Solo se permiten imágenes."));
}});

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));
app.use("/uploads",express.static(uploadDir));

app.post("/api/register",async(req,res)=>{
 try{
  const {name,email,password}=req.body;
  if(!name||!email||!password) return res.status(400).json({error:"Completa todos los campos."});
  if(password.length<6) return res.status(400).json({error:"La contraseña debe tener mínimo 6 caracteres."});
  const hash=await bcrypt.hash(password,10), id=randomUUID(), created=new Date().toISOString();
  db.prepare("INSERT INTO users VALUES (?,?,?,?,?)").run(id,name,email.toLowerCase(),hash,created);
  res.json({ok:true,user:{id,name,email:email.toLowerCase()}});
 }catch(e){res.status(400).json({error:e.message.includes("UNIQUE")?"Ese correo ya está registrado.":"No se pudo crear la cuenta."});}
});

app.post("/api/login",async(req,res)=>{
 const {email,password}=req.body||{};
 const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
 if(!u||!(await bcrypt.compare(password||"",u.password))) return res.status(401).json({error:"Correo o contraseña incorrectos."});
 res.json({ok:true,user:{id:u.id,name:u.name,email:u.email}});
});

app.get("/api/trucks",(req,res)=>{
 const rows=db.prepare(`SELECT trucks.id,trucks.name,trucks.description,trucks.image,trucks.likes,trucks.created_at,users.name AS author
 FROM trucks JOIN users ON users.id=trucks.user_id ORDER BY trucks.created_at DESC`).all();
 res.json(rows);
});

app.post("/api/trucks",upload.single("image"),(req,res)=>{
 const {userId,name,description}=req.body||{};
 if(!userId||!name) return res.status(400).json({error:"Falta usuario o nombre del camión."});
 const user=db.prepare("SELECT id FROM users WHERE id=?").get(userId);
 if(!user) return res.status(401).json({error:"Usuario no válido."});
 const image=req.file?"/uploads/"+req.file.filename:"";
 const id=randomUUID();
 db.prepare("INSERT INTO trucks VALUES (?,?,?,?,?,?,?)").run(id,userId,name,description||"",image,0,new Date().toISOString());
 res.json({ok:true});
});

app.post("/api/trucks/:id/like",(req,res)=>{
 db.prepare("UPDATE trucks SET likes=likes+1 WHERE id=?").run(req.params.id);
 res.json({ok:true});
});

app.use((err,req,res,next)=>res.status(400).json({error:err.message||"Error"}));
app.listen(PORT,()=>console.log(`GomezTruckS'tylo en http://localhost:${PORT}`));
